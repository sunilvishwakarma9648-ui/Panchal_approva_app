# Panchal Approva Institute — Flutter App

Starter Flutter codebase implementing the app blueprint:
auto-login, dashboard, course catalog, student learning tabs,
certificates, and contact/support.

## Setup

1. Install Flutter SDK: https://docs.flutter.dev/get-started/install
2. Extract this project, then from its root run:
   ```
   flutter pub get
   flutter run
   ```

## What's included

- `lib/main.dart` — app entry point & theme
- `lib/screens/splash_screen.dart` — checks saved session → auto-login
- `lib/screens/login_screen.dart`, `signup_screen.dart` — auth forms
- `lib/screens/dashboard_screen.dart` — Home tab + bottom navigation shell
- `lib/screens/courses_screen.dart` — course catalog grouped by category
- `lib/screens/student_dashboard_screen.dart` — study material, video
  lectures, tests/quizzes, attendance & fees (tabbed)
- `lib/screens/certificates_screen.dart` — certificate download + QR
- `lib/screens/contact_screen.dart` — WhatsApp/Call/Email/Map, institute info
- `lib/utils/session_manager.dart` — SharedPreferences-based auto-login
- `lib/models/course.dart` — course data model + sample catalog

## What's mocked (needs a real backend)

Every screen has a `// TODO:` marking where it currently uses fake/demo
data and where to plug in real API calls:

- **Auth**: `login_screen.dart` / `signup_screen.dart` simulate a network
  call and store a fake JWT. Replace with your actual auth API.
- **Courses/content**: `models/course.dart` is a static list — swap for
  an API call once an admin panel exists.
- **Payments**: `student_dashboard_screen.dart` "Pay Now" button is a
  stub — wire up Razorpay or Paytm's Flutter SDK there.
- **Certificates**: download/QR buttons are stubs — connect to your
  certificate-generation service.
- **Push notifications**: not yet included — add `firebase_messaging`
  once you set up a Firebase project.
- **Admin panel**: this app is the student-facing app only; the admin
  dashboard for Sunil Panchal ji would be a separate small app or a
  web panel hitting the same backend.

## Suggested backend

Firebase (Auth + Firestore + Storage + Cloud Messaging) is the fastest
way to get this fully working without maintaining your own server.
