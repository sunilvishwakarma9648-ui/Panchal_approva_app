import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const PanchalApprovaApp());
}

class PanchalApprovaApp extends StatelessWidget {
  const PanchalApprovaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Panchal Approva Institute',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF1A3C6E),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1A3C6E)),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1A3C6E),
          foregroundColor: Colors.white,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
