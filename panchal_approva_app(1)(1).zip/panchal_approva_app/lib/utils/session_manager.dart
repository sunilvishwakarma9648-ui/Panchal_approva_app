import 'package:shared_preferences/shared_preferences.dart';

/// Handles saving/reading the login session so returning users
/// skip the Login screen and go straight to the Dashboard.
class SessionManager {
  static const _keyToken = 'auth_token';
  static const _keyName = 'user_name';
  static const _keyPhone = 'user_phone';
  static const _keyEmail = 'user_email';
  static const _keyCourse = 'user_course_interest';

  /// Call this after a successful login/signup (with the token your
  /// backend returns, e.g. a JWT).
  static Future<void> saveSession({
    required String token,
    required String name,
    required String phone,
    required String email,
    String courseInterest = '',
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyToken, token);
    await prefs.setString(_keyName, name);
    await prefs.setString(_keyPhone, phone);
    await prefs.setString(_keyEmail, email);
    await prefs.setString(_keyCourse, courseInterest);
  }

  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_keyToken);
    return token != null && token.isNotEmpty;
  }

  static Future<Map<String, String>> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'name': prefs.getString(_keyName) ?? '',
      'phone': prefs.getString(_keyPhone) ?? '',
      'email': prefs.getString(_keyEmail) ?? '',
      'course': prefs.getString(_keyCourse) ?? '',
    };
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
