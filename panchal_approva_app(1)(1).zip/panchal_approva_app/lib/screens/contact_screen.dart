import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

/// Official institute details — used across the Contact page and app footer.
class InstituteInfo {
  static const name = 'Panchal Approva Institute';
  static const managerName = 'Sunil Panchal';
  static const phone = '+916388328424'; // no spaces, for tel:/wa.me links
  static const displayPhone = '+91 6388328424';
  static const email = 'sunilvishwakarma9648@gmail.com';
  static const address = 'Salon, Raebareli, Uttar Pradesh';
}

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  Future<void> _launch(Uri uri) async {
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Contact & Support')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(InstituteInfo.name,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const Text('Manager: ${InstituteInfo.managerName}'),
          const SizedBox(height: 20),

          // WhatsApp
          Card(
            child: ListTile(
              leading: const Icon(Icons.chat, color: Colors.green),
              title: const Text('Chat on WhatsApp'),
              subtitle: const Text(InstituteInfo.displayPhone),
              onTap: () => _launch(Uri.parse('https://wa.me/${InstituteInfo.phone.replaceFirst('+', '')}')),
            ),
          ),
          // Call
          Card(
            child: ListTile(
              leading: const Icon(Icons.call, color: Colors.blue),
              title: const Text('Call Institute'),
              subtitle: const Text(InstituteInfo.displayPhone),
              onTap: () => _launch(Uri(scheme: 'tel', path: InstituteInfo.phone)),
            ),
          ),
          // Email
          Card(
            child: ListTile(
              leading: const Icon(Icons.email_outlined, color: Colors.orange),
              title: const Text('Email Us'),
              subtitle: const Text(InstituteInfo.email),
              onTap: () => _launch(Uri(scheme: 'mailto', path: InstituteInfo.email)),
            ),
          ),
          // Location / map
          Card(
            child: ListTile(
              leading: const Icon(Icons.location_on_outlined, color: Colors.red),
              title: const Text('Institute Location'),
              subtitle: const Text(InstituteInfo.address),
              onTap: () => _launch(
                Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(InstituteInfo.address)}'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
