import 'package:flutter/material.dart';

class StudentDashboardScreen extends StatelessWidget {
  const StudentDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My Learning'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'Study Material'),
              Tab(text: 'Video Lectures'),
              Tab(text: 'Tests & Quizzes'),
              Tab(text: 'Attendance & Fees'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _StudyMaterialTab(),
            _VideoLecturesTab(),
            _TestsTab(),
            _AttendanceFeesTab(),
          ],
        ),
      ),
    );
  }
}

class _StudyMaterialTab extends StatelessWidget {
  const _StudyMaterialTab();
  @override
  Widget build(BuildContext context) {
    final files = ['Module 1 - Introduction.pdf', 'Module 2 - Practice Notes.pdf', 'Module 3 - Assignment.pdf'];
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: files.length,
      itemBuilder: (_, i) => Card(
        child: ListTile(
          leading: const Icon(Icons.picture_as_pdf_outlined, color: Colors.red),
          title: Text(files[i]),
          trailing: IconButton(
            icon: const Icon(Icons.download_outlined),
            onPressed: () {
              // TODO: download PDF from your storage bucket / API.
            },
          ),
        ),
      ),
    );
  }
}

class _VideoLecturesTab extends StatelessWidget {
  const _VideoLecturesTab();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          color: Colors.red.shade50,
          child: const ListTile(
            leading: Icon(Icons.podcasts, color: Colors.red),
            title: Text('LIVE: Web Dev Batch — Today 6:00 PM'),
            subtitle: Text('Tap to join the live class link'),
          ),
        ),
        const SizedBox(height: 8),
        ...List.generate(
          3,
          (i) => Card(
            child: ListTile(
              leading: const Icon(Icons.play_circle_outline, color: Color(0xFF1A3C6E)),
              title: Text('Recorded Lecture ${i + 1}'),
              subtitle: const Text('45 min'),
            ),
          ),
        ),
      ],
    );
  }
}

class _TestsTab extends StatelessWidget {
  const _TestsTab();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.quiz_outlined, color: Colors.orange),
            title: const Text('Module 1 Quiz'),
            subtitle: const Text('10 questions • Auto-graded'),
            trailing: ElevatedButton(onPressed: () {}, child: const Text('Start')),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.check_circle_outline, color: Colors.green),
            title: const Text('Module 0 Quiz'),
            subtitle: const Text('Completed • Score: 8/10'),
          ),
        ),
      ],
    );
  }
}

class _AttendanceFeesTab extends StatelessWidget {
  const _AttendanceFeesTab();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Attendance', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: 0.85, minHeight: 10, borderRadius: BorderRadius.circular(6)),
        const SizedBox(height: 4),
        const Text('85% attendance this month'),
        const SizedBox(height: 24),
        const Text('Fee Payment History', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        Card(
          child: ListTile(
            leading: const Icon(Icons.receipt_long_outlined),
            title: const Text('Installment 1 — Paid'),
            subtitle: const Text('Receipt #INV-1001'),
            trailing: IconButton(icon: const Icon(Icons.download_outlined), onPressed: () {}),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.pending_outlined, color: Colors.orange),
            title: const Text('Installment 2 — Due'),
            trailing: ElevatedButton(
              onPressed: () {
                // TODO: integrate Razorpay/Paytm payment gateway here.
              },
              child: const Text('Pay Now'),
            ),
          ),
        ),
      ],
    );
  }
}
