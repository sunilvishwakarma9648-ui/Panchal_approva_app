import 'package:flutter/material.dart';
import '../models/course.dart';

class CoursesScreen extends StatelessWidget {
  const CoursesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Our Courses')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: courseCategories.map((category) {
          final coursesInCategory = allCourses.where((c) => c.category == category).toList();
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(category, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...coursesInCategory.map((course) => Card(
                      child: ListTile(
                        leading: Text(course.icon, style: const TextStyle(fontSize: 24)),
                        title: Text(course.title),
                        subtitle: Text('Duration: ${course.duration}'),
                        trailing: ElevatedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Enrollment request sent for ${course.title}')),
                            );
                            // TODO: Hook this up to your enrollment/payment API.
                          },
                          child: const Text('Enroll'),
                        ),
                      ),
                    )),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
