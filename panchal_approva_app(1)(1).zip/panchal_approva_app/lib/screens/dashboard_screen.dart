import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';
import 'courses_screen.dart';
import 'student_dashboard_screen.dart';
import 'certificates_screen.dart';
import 'contact_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _index = 0;

  final _pages = const [
    _HomeTab(),
    CoursesScreen(),
    StudentDashboardScreen(),
    CertificatesScreen(),
    ContactScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pages[_index]),
      bottomNavigationBar: AppBottomNav(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
      ),
    );
  }
}

/// Home / Dashboard tab content.
class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Welcome banner
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1A3C6E),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              const CircleAvatar(
                radius: 28,
                backgroundColor: Colors.white,
                child: Icon(Icons.school, color: Color(0xFF1A3C6E), size: 32),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Panchal Approva Institute',
                        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text('Learn. Grow. Succeed.', style: TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Quick Enrollment button
        ElevatedButton.icon(
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CoursesScreen()),
            );
          },
          icon: const Icon(Icons.add_circle_outline),
          label: const Text('Quick Enrollment'),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(48),
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
          ),
        ),
        const SizedBox(height: 24),

        // Notice board
        const _SectionTitle('Notice Board'),
        const _NoticeCard(title: 'New ADCA Batch Starting', subtitle: 'Admissions open — batch starts 1st Oct'),
        const _NoticeCard(title: 'CCC Exam Date Announced', subtitle: 'Exam scheduled for 20th Sept'),
        const SizedBox(height: 24),

        // Top student reviews
        const _SectionTitle('Success Stories'),
        const _ReviewCard(name: 'Ravi Kumar', course: 'Web Development', quote: 'Got placed within 2 months of course completion.'),
        const _ReviewCard(name: 'Priya Singh', course: 'Tally Prime with GST', quote: 'Very practical, job-ready training.'),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
    );
  }
}

class _NoticeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const _NoticeCard({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.campaign_outlined, color: Colors.orange),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  final String name;
  final String course;
  final String quote;
  const _ReviewCard({required this.name, required this.course, required this.quote});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text('$name — $course'),
        subtitle: Text('"$quote"'),
      ),
    );
  }
}
