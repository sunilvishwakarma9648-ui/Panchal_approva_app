class Course {
  final String title;
  final String category;
  final String icon; // simple emoji/icon placeholder, swap for real assets
  final String duration;

  const Course({
    required this.title,
    required this.category,
    required this.icon,
    required this.duration,
  });
}

/// Static demo data reflecting the courses offered by
/// Panchal Approva Institute. Replace with an API call to your
/// backend / admin panel once it's ready.
const List<Course> allCourses = [
  // Programming & Tech
  Course(title: 'AI & Machine Learning', category: 'Programming & Tech', icon: '🤖', duration: '6 months'),
  Course(title: 'Web Development (MERN / Full Stack)', category: 'Programming & Tech', icon: '💻', duration: '6 months'),
  Course(title: 'App Development (Android / Flutter)', category: 'Programming & Tech', icon: '📱', duration: '5 months'),
  Course(title: 'Python & Data Science', category: 'Programming & Tech', icon: '🐍', duration: '4 months'),

  // Core Computer Courses
  Course(title: 'ADCA (Advanced Diploma in Computer Applications)', category: 'Core Computer Courses', icon: '🖥️', duration: '1 year'),
  Course(title: 'DCA (Diploma in Computer Applications)', category: 'Core Computer Courses', icon: '🖥️', duration: '6 months'),
  Course(title: 'O Level', category: 'Core Computer Courses', icon: '📜', duration: '1 year'),
  Course(title: 'CCC (Course on Computer Concepts)', category: 'Core Computer Courses', icon: '📜', duration: '3 months'),

  // Designing & Media
  Course(title: 'Graphic Designing', category: 'Designing & Media', icon: '🎨', duration: '3 months'),
  Course(title: 'UI/UX Design', category: 'Designing & Media', icon: '🎨', duration: '3 months'),
  Course(title: 'Video Editing', category: 'Designing & Media', icon: '🎬', duration: '2 months'),

  // Accounting & Business
  Course(title: 'Tally Prime with GST', category: 'Accounting & Business', icon: '🧾', duration: '3 months'),
  Course(title: 'MS Office & Advanced Excel', category: 'Accounting & Business', icon: '📊', duration: '2 months'),
];

List<String> get courseCategories =>
    allCourses.map((c) => c.category).toSet().toList();
